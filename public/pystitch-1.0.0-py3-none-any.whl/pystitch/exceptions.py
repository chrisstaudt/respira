class TooManyColorChangesError(Exception):
    '''Raised when number of color changes exceeds permitted total'''
